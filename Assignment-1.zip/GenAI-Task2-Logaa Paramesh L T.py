#Create a list of products containing at least 6 product names(strings).
products=["apple","orange","banana","watermelon","kiwi","grapes"]
sample_product=("Apple",100,"Fruits")
#Creating a new list of categories and making it a set.
categories=["Fruits","Fruits","Fruits","Fruits","Fruits","Fruits"]
categories_set=set(categories)
print("Categories Set:")
print(categories_set)
#Adding new categories to the set and to show duplicates are ignored.
categories_set.add("Vegetables")
categories_set.add("Fruits")
print(categories_set)
#Checking whether a category exists in the set
print("\nDoes 'Fruits' exist?", "Fruits" in categories_set)
# Extra (Optional): Count the total number of unique categories
print("\nTotal Unique Categories:", len(categories_set))