#Create a list of products containing at least 6 product names(strings).
products=["apple","orange","banana","watermelon","kiwi","grapes"]
#Create a sample_product tuple containing product name(string), price(float), and category(string).
sample_product=("Apple",100,"Fruits")
#printing 2nd and last product from the products list. 
print(products[1])
print(products[-1])
#Appending new products name to the products list.
products.append("Berry")
products.append("Muskmelon")
#Printing the updated list
print(products)
#Extra optional:Converting the sample_product tuple to a list, changing the price, and converting it back to a tuple.
sample_product_list=list(sample_product)
sample_product_list[1]=150
print(sample_product_list)
sample_list=tuple(sample_product_list)