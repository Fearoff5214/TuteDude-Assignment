#Intializing the list and dictionary
products=["apple","orange","banana","watermelon","kiwi","grapes","Tomato"]
price_dict={"apple":100,"orange":80,"banana":50,"watermelon":120,"kiwi":90,"grapes":70}
#Creating Tuple from products list and price_dict dictionary.
products_name=tuple(products)
price=tuple(price_dict.values())
categories_set=set(["Fruits","Vegetaries"])
category=tuple(categories_set)
#Creating a new dictionary category_to_products that maps each category to a list of product names in that category.
category_to_products={"Fruits":["apple","orange","banana","watermelon","kiwi","grapes"],"Vegetables":["Tomato"]}
#Printing all products in a category with maximum no. of products.
print(max(category_to_products.values()))