#Creating a dictionary price_dict where keys are product names and values are prices with 6 entries.
price_dict={"apple":100,"orange":80,"banana":50,"watermelon":120,"kiwi":90,"grapes":70}
#Adding a product to the price_dict with its price.
price_dict["Tomato"]=40
#Updating price of existing product in the price_dict.
price_dict["banana"]=40
#Removing a product from price_dict by name.
del price_dict["kiwi"]
#Average of all the product prices in the price_dict.
average_price=sum(price_dict.values())/len(price_dict)
#Extra(optional):Printing the max and min values from price_dict.
print(max(price_dict.values()))
print(min(price_dict.values()))

