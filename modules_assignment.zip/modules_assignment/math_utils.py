#Task-1
def add(a,b):
    return a+b
def subtract(a,b):
    return a-b
def square(n):
    return n**n