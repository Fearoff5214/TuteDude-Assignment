#task-1
import math_utils
from math_utils import subtract,add,square
print(add(2,1))
print(subtract(2,1))
print(square(2))
#task 2
import string_utils
from string_utils import capitalize_words,reverse_string,word_count
print(capitalize_words("hello there"))
print(reverse_string("hello there"))
print(word_count("hello there"))
#task 4 
import shop_package.discount as disc
from shop_package.billing import calculate_total,apply_tax
print(disc.apply_discount(1000,10))
print(calculate_total([100,200,300]))
print(apply_tax(100))
print(disc.flat_discount(100))

