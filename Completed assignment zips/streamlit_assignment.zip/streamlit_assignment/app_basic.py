# Task 1: Basic Streamlit App

import streamlit as st

st.set_page_config(page_title="Simple Greeting App", page_icon="👋")
st.title("Welcome to Streamlit!")

name = st.text_input("Enter your name", placeholder="Type your name here")

if st.button("Greet Me"):
    if name.strip():
        st.success(f"Hello, {name}!")
    else:
        st.warning("Please enter your name.")