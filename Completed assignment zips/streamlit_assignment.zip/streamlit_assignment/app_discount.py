import streamlit as st

st.title("Price Calculator")

price = st.number_input("Enter Product Price", min_value=0.0)
discount = st.slider("Discount (%)", 0, 50, 10)

if st.button("Calculate"):
    final_price = price * (1 - discount / 100)

    st.success(f"Final Price: ₹{final_price:.2f}")
    st.table([["Before", price], ["After", final_price]])