# Task 9
#Added it as a python file instead of just a Text file

print("1. Pipelines keep preprocessing and model training together.")

print("\n2. Pipelines reduce code repetition and help avoid data leakage.")

print("\n3. Manual preprocessing requires separate steps.")
print("Pipeline preprocessing automates all steps in one workflow.")