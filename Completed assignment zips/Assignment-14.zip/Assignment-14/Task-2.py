# Task 2

import pandas as pd

df = pd.read_csv("D:\\GenAI course\\Assignment-14\\StudentsPerformance.csv")

print("Columns in the dataset:")
print(df.columns)

print("\nNo date column is available.")
print("No text column is available.")
print("Task skipped.")