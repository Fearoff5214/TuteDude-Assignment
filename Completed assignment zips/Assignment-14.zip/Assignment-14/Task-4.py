# Task 4

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder

df = pd.read_csv("D:\\GenAI course\\Assignment-14\\StudentsPerformance.csv")

num_cols = ["math score", "reading score", "writing score"]

cat_cols = [
    "gender",
    "race/ethnicity",
    "parental level of education",
    "lunch",
    "test preparation course"
]

ct = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(), cat_cols)
    ],
    remainder="passthrough"
)

data = ct.fit_transform(df)

print(data)
print(data.shape)