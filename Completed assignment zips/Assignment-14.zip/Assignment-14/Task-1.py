# Part 1
# Task 1

import pandas as pd

df = pd.read_csv("D:\\GenAI course\\Assignment-14\\StudentsPerformance.csv")

df["total_score"] = (
    df["math score"] +
    df["reading score"] +
    df["writing score"]
)

df["average_score"] = df["total_score"] / 3

print(df.head())