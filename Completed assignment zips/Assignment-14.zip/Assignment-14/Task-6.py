# Task 6

import pandas as pd
from sklearn.preprocessing import MinMaxScaler

df = pd.read_csv("D:\\GenAI course\\Assignment-14\\StudentsPerformance.csv")

X = df[["math score", "reading score", "writing score"]]

scaler = MinMaxScaler()

scaled = scaler.fit_transform(X)

scaled_df = pd.DataFrame(
    scaled,
    columns=["math score", "reading score", "writing score"]
)

print(scaled_df.head())

print("\nMinimum")
print(scaled_df.min())

print("\nMaximum")
print(scaled_df.max())