# Part 3
# Task 5

import pandas as pd
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("D:\\GenAI course\\Assignment-14\\StudentsPerformance.csv")

X = df[["math score", "reading score", "writing score"]]

scaler = StandardScaler()

scaled = scaler.fit_transform(X)

scaled_df = pd.DataFrame(
    scaled,
    columns=["math score", "reading score", "writing score"]
)

print(scaled_df.head())

print("\nMean")
print(scaled_df.mean())

print("\nStandard Deviation")
print(scaled_df.std())