# Part 2
# Task 3

import pandas as pd

df = pd.read_csv("D:\\GenAI course\\Assignment-14\\StudentsPerformance.csv")

cat_cols = df.select_dtypes(include="object").columns

print("Categorical Columns:")
print(cat_cols)

df = pd.get_dummies(df, columns=cat_cols)

print("\nEncoded Data")
print(df.head())