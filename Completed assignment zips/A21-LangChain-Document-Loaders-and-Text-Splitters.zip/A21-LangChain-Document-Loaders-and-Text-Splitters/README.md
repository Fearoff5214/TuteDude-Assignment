# Assignment 21: LangChain Document Loaders & Text Splitters

## Files Used

- notes.txt
- employees.csv
- Logaa_Paramesh_Resume.pdf

## Libraries Used

- LangChain
- LangChain Community
- LangChain Text Splitters
- PyPDF
- BeautifulSoup4

## What I Did

- Loaded text, CSV, PDF, folder, and web documents with LangChain loaders.
- Checked document metadata and content.
- Compared CharacterTextSplitter and RecursiveCharacterTextSplitter.
- Used MarkdownHeaderTextSplitter to keep sections together.
- Used a simple semantic-style grouping example at the end.

## How to run this locally

1. Open `A21_Document_Loaders_Text_Splitters.ipynb` in Jupyter or VS Code.
2. Make sure the `data` folder is in the same directory as the notebook.
3. Run the cells from top to bottom.
4. If needed, install the packages from `requirements.txt` first.

This assignment helped me understand how different loaders and splitters behave before moving into RAG-style document workflows.
