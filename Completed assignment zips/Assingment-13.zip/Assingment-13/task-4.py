# Part 1
# Task 4

from pathlib import Path

import pandas as pd
import requests

api_key = "fea516c366ad73f57dbc951bef5513ac"
url = "https://api.themoviedb.org/3/movie/popular"

try:
    response = requests.get(url, params={"api_key": api_key}, timeout=10)
    response.raise_for_status()
    data = response.json().get("results", [])

    movie_records = []
    for movie in data:
        movie_records.append({
            "Title": movie.get("title", "Unknown"),
            "Release Date": movie.get("release_date", "N/A"),
            "Rating": movie.get("vote_average", 0),
            "Popularity": movie.get("popularity", 0),
        })

    movies_df = pd.DataFrame(movie_records)
    movies_df.to_csv("tmdb_movies.csv", index=False)
    print("Data saved successfully.")

except Exception as exc:
    print("Could not fetch TMDB data:", exc)
    if Path("tmdb_movies.csv").exists():
        movies_df = pd.read_csv("tmdb_movies.csv")
    else:
        movies_df = pd.DataFrame([
            {"Title": "Example movie", "Release Date": "2024-01-01", "Rating": 7.5, "Popularity": 100.0}
        ])

print(movies_df.head())