# Task 1
from pathlib import Path

import pandas as pd

data_path = Path("students_cleaned.csv") if Path("students_cleaned.csv").exists() else Path(r"C:\Users\DS\Downloads\StudentsPerformance.csv")
students_df = pd.read_csv(data_path)

print("Shape of dataset:")
print(students_df.shape)

print("\nColumn names:")
print(students_df.columns)

print("\nFirst 5 rows:")
print(students_df.head())

print("\nData types:")
print(students_df.dtypes)

print("\nMissing values:")
print(students_df.isnull().sum())

print("\nDuplicate rows:")
print(students_df.duplicated().sum())

print("\nSummary statistics:")
print(students_df.describe())