# Task 6
from pathlib import Path

import pandas as pd

data_path = Path("students_cleaned.csv") if Path("students_cleaned.csv").exists() else Path(r"C:\Users\DS\Downloads\StudentsPerformance.csv")
students_df = pd.read_csv(data_path)

numeric_columns = students_df.select_dtypes(include=["int64", "float64"]).columns
categorical_columns = students_df.select_dtypes(include=["object"]).columns

for column in numeric_columns:
    students_df[column] = students_df[column].fillna(students_df[column].mean())

for column in categorical_columns:
    students_df[column] = students_df[column].fillna(students_df[column].mode()[0])

students_df = students_df.drop_duplicates()
students_df.columns = students_df.columns.str.lower().str.replace(" ", "_")

print(students_df.head())

print("\nShape:")
print(students_df.shape)

students_df.to_csv("students_cleaned.csv", index=False)
print("\nCleaned dataset saved successfully.")