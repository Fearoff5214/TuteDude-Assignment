# Part 3
# Task 8

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("D:\\GenAI course\\Assingment-13\\students_cleaned.csv")

print(df["math_score"].describe())
print(df["gender"].value_counts())

plt.hist(df["math_score"], bins=10)
plt.title("Math Score Distribution")
plt.show()

sns.kdeplot(df["math_score"], fill=True)
plt.title("Density Plot")
plt.show()

sns.boxplot(y=df["math_score"])
plt.title("Box Plot")
plt.show()

sns.countplot(data=df, x="gender")
plt.title("Gender Count")
plt.show()