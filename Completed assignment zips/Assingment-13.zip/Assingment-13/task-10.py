# Task 10

import pandas as pd

df = pd.read_csv("D:\\GenAI course\\Assingment-13\\students_cleaned.csv")

print("Average Scores")
print(df[["math_score", "reading_score", "writing_score"]].mean())

print("\nHighest Math Score:", df["math_score"].max())
print("Lowest Math Score:", df["math_score"].min())

print("\nMale Students:", (df["gender"] == "male").sum())
print("Female Students:", (df["gender"] == "female").sum())

print("\nCorrelation")
print(df[["math_score", "reading_score", "writing_score"]].corr())