# Task 3
import sqlite3
import pandas as pd

conn = sqlite3.connect("sample.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS employees(
    id INTEGER,
    name TEXT,
    department TEXT,
    salary INTEGER
)
""")

cursor.execute("DELETE FROM employees")

employee_rows = [
    (1, "Arun", "HR", 35000),
    (2, "Priya", "IT", 50000),
    (3, "Rahul", "Sales", 42000),
    (4, "Neha", "Finance", 48000),
    (5, "Kiran", "Marketing", 39000),
]

cursor.executemany("INSERT INTO employees VALUES (?,?,?,?)", employee_rows)
conn.commit()

employee_df = pd.read_sql("SELECT * FROM employees", conn)

print(employee_df)

conn.close()