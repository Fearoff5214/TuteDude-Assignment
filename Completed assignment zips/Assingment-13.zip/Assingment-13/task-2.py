# Task 2
import pandas as pd

products_df = pd.read_json("D:\\GenAI course\\Assingment-13\\products.json")

print(products_df)

print("\nShape:")
print(products_df.shape)

print("\nColumns:")
print(products_df.columns)