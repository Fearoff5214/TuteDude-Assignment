# Task 5
from pathlib import Path

import pandas as pd

data_path = Path("students_cleaned.csv") if Path("students_cleaned.csv").exists() else Path(r"C:\Users\DS\Downloads\StudentsPerformance.csv")
students_df = pd.read_csv(data_path)

print("Shape of dataset:")
print(students_df.shape)

print("\nData types:")
print(students_df.dtypes)

print("\nNumerical columns:")
print(students_df.select_dtypes(include=["int64", "float64"]).columns)

print("\nCategorical columns:")
print(students_df.select_dtypes(include=["object"]).columns)

print("\nMissing values:")
print(students_df.isnull().sum())

print("\nSummary statistics:")
print(students_df.describe())

print("\nUnique values:")
print(students_df.nunique())