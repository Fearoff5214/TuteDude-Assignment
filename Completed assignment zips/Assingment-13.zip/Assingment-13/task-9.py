# Task 9

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("D:\\GenAI course\\Assingment-13\\students_cleaned.csv")

print("Correlation")
print(df[["math_score", "reading_score", "writing_score"]].corr())

print("\nAverage Math Score by Gender")
print(df.groupby("gender")["math_score"].mean())

plt.scatter(df["math_score"], df["reading_score"])
plt.title("Math vs Reading")
plt.show()

sns.barplot(data=df, x="gender", y="math_score")
plt.title("Average Math Score")
plt.show()

sns.boxplot(data=df, x="gender", y="reading_score")
plt.title("Reading Score")
plt.show()

sns.heatmap(df[["math_score", "reading_score", "writing_score"]].corr(), annot=True)
plt.show()

sns.pairplot(df[["math_score", "reading_score", "writing_score"]])
plt.show()