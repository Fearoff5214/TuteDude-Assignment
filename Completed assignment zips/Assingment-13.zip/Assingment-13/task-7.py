# Task 7
from pathlib import Path

import pandas as pd

data_path = Path("D:\\GenAI course\\Assingment-13\\students_cleaned.csv")
cleaned_df = pd.read_csv(data_path)

cleaned_df.columns = cleaned_df.columns.str.lower().str.replace(" ", "_")
encoded_df = pd.get_dummies(cleaned_df)

print("First 5 rows:")
print(encoded_df.head())

features = encoded_df.drop("math_score", axis=1)
target = encoded_df["math_score"]

print("\nFeatures:")
print(features.head())

print("\nTarget:")
print(target.head())